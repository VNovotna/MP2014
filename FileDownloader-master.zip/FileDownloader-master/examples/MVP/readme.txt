Nette Framework skeleton
========================

The Basic project structure for our application.

See: http://nettephp.com/quick-start


Installing
----------

Download Nette Framework (http://nettephp.com/download) and extract the folder 'Nette' to your project's library directory 'libs'.
Your library directory should now contain the Nette directory which contains all of the Nette Framework units. Now the Nette Framework is
successfully installed and ready to use.


Application Structure on the File System
----------------------------------------

Make directories 'app/cache' and 'app/log' writable.


Bootstrapping
-------------

Presenters & Views
------------------
